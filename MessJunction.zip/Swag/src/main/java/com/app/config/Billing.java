package com.app.config;

public class Billing {

	public void getOrder() {
		
	}
}
