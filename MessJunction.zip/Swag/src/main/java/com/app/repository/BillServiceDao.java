package com.app.repository;

public interface BillServiceDao {
	
	

}
