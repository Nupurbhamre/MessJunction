package com.app.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Customer{
@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String userId;
	private String password;
	private long PhoneNumber;
	public int getId() {
		return id;
	}
	public String getEmail() {
		return userId;
	}
	public String getPassword() {
		return password;
	}
	public long getPhoneNumber() {
		return PhoneNumber;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setEmail(String email) {
		this.userId = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", email=" + userId + ", password=" + password + ", PhoneNumber=" + PhoneNumber
				+ "]";
	}
}
	
