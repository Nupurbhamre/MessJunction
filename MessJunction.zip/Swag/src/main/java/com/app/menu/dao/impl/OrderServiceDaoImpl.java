package com.app.menu.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.app.menu.dao.OrderServiceDao;
import com.app.model.Menu;

import jakarta.annotation.PostConstruct;

@Configuration

public class OrderServiceDaoImpl extends JdbcDaoSupport implements OrderServiceDao {
	
	@Autowired DataSource datasource;
	@PostConstruct
	private void init() {
		setDataSource(datasource);
	}

	@Override
	public Menu getOrderById(int id) {
		// TODO Auto-generated method stub
		
		String sql="select name,price from Menu where id=?";
		
		return getJdbcTemplate().queryForObject(sql, new Object[] {id},new RowMapper<Menu>(){
		
			public Menu mapRow(ResultSet rs, int rowNum)throws SQLException{
				Menu cust=new Menu();
				cust.setName(rs.getString(1));
				cust.setPrice(rs.getInt(2));
				return cust;
			}
			});
	}

	@Override
	public int getBill(int price) {
		// TODO Auto-generated method stub
		return 0;
	}

		
	}

