package com.app.menu.dao;

import com.app.model.Menu;

public interface OrderServiceDao {

	public Menu getOrderById(int id);
	
	public int getBill(int price);
}
